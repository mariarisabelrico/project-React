import React from 'react'
import Products from './Products';



const Home = () =>{
  return (
    <div className='hero'>
    <div className="card bg-dark text-white border-0">
  <img src="/assets/tienda3.webp" className="card-img" alt="backgroung" height="600px"/>
  <div className="card-img-overlay d-flex flex-column justify-content-center">
    
  </div>
  </div> 
  <Products/>
  
  
  </div>
  
    
  );
};

export default Home