import React from 'react'

const readls = () => {
    const data  =  localStorage.getItem('cart') || [];
    console.log(data)
  }
const ListCart = () => {
  return (
    <div>
    <div>
    <img src={} alt={}/>  
    <p></p>
    </div>
    
    </div>
  )
}

export default ListCart