import './App.css';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import {Route,Routes} from 'react-router-dom'
import Products from './pages/Products';
import Product from './pages/Product';

function App() {
  return (
  <>
  
  <Navbar/> 
  

  <Routes>
  <Route path='/' element={<Home/>}/>
  <Route path='/products' element={<Products/>}/>  
  <Route path='/products/:id' element={<Product/>}/>   
  </Routes>
   
  
  {/* <Home/> */}
  

  </>
  );
}

export default App;
